CREATE DATABASE SalesDB;

CREATE TABLE SalesData (
    Date DATE NOT NULL,
    Product VARCHAR(50) NOT NULL,
    QuantitySold INTEGER NOT NULL,
    TotalRevenue DECIMAL(10, 2) NOT NULL
);

SELECT * FROM SalesData;
