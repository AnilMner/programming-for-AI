CREATE DATABASE CustomerDB;

CREATE TABLE Purchases (
    PurchaseDate DATE,
    CustomerID INT,
    PurchaseAmount DECIMAL(10, 2),
    PaymentMethod VARCHAR(50)
);


SELECT * FROM Purchases;


